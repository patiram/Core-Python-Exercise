#Duck Typing and Easier to ask forgiveness than Permission (EAFP)

class Duck:
	def quack(self):
		print('Quack, quack')
	def flap(self):
		print('Flap, flap')
class Person: