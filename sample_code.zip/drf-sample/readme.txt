The default directory structure has been changed:
Following configuration is necessary:

In server/config/settings.py

ROOT_URLCONF = 'urls'
    changes to
ROOT_URLCONF = 'server.urls'

WSGI_APPLICATION = 'wsgi.application'
    changes to
WSGI_APPLICATION = 'config.wsgi.application'
In server/config/wsgi.py

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "drf_sample.settings")
    changes to
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
In server/manage.py:

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "drf_sample.settings")
    changes to
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")