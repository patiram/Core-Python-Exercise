from django.apps import AppConfig


class ScrumboardConfig(AppConfig):
    name = 'scrumboard'
