Everything is an object in python, even functions. 

A function can be assigned to a variable, passed to another function and can be returned from another function.