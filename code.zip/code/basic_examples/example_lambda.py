'''

@author: patir
'''

test = lambda x: x**2
print (test(3))